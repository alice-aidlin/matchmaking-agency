/* Assignment: 3 Author: Alice Aidlin, ID: 206448326   */
using namespace std;
#include "menu.h"



int main()
{
	Menu::Menu();//call ctor

	return 0;
}

